<?php
session_destroy();
redir("./");
?>