# tienda
Tienda PHP, MYSQL

Esta tienda ha sido creado con el fin de enseñar conceptos basicos de programacion en php, mysql, ajax, jquery

Tienda creada mediante video tutorial en youtube

Tienda: https://youtu.be/gPGkeCdYZnU

Canal: https://www.youtube.com/AnySlehider
